import * as admin from 'firebase-admin';
import { gfetch, pollOperation } from './gcpAuth';
import { TenantConfig, TenantOnboardingInput } from './types';

const CLOUD_RESOURCE_MANAGER = 'https://cloudresourcemanager.googleapis.com/v3';
const FIREBASE_MGMT = 'https://firebase.googleapis.com/v1beta1';
const SERVICE_USAGE = 'https://serviceusage.googleapis.com/v1';
const CLOUD_BILLING = 'https://cloudbilling.googleapis.com/v1';
const FIRESTORE = 'https://firestore.googleapis.com/v1';
const FIREBASE_RULES = 'https://firebaserules.googleapis.com/v1';

// Configure these for your control plane. See README.
const BILLING_ACCOUNT = process.env.CONTROL_PLANE_BILLING_ACCOUNT; // 'billingAccounts/XXXXXX-XXXXXX-XXXXXX'
const PARENT_RESOURCE = process.env.CONTROL_PLANE_PARENT_RESOURCE; // 'folders/123...' or 'organizations/123...' — omit if you have no GCP org
const DEFAULT_FIRESTORE_REGION = process.env.CONTROL_PLANE_FIRESTORE_REGION || 'europe-west1';

const REQUIRED_APIS = [
  'firebase.googleapis.com',
  'firestore.googleapis.com',
  'identitytoolkit.googleapis.com',
  'firebaserules.googleapis.com',
];

const DEFAULT_RULES = `
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isSignedIn() { return request.auth != null; }
    function isAdmin() { return isSignedIn() && request.auth.token.role == 'tenantAdmin'; }
    function isStaff() { return isSignedIn() && request.auth.token.role in ['tenantAdmin', 'staff']; }

    match /{document=**} {
      allow read: if isStaff();
      allow write: if isAdmin();
    }
  }
}
`;

function generateProjectId(tenantCode: string): string {
  // Cloud project IDs: 6-30 chars, lowercase letters/digits/hyphens, must start with a letter,
  // and must be globally unique across all of Google Cloud — hence the random suffix.
  const suffix = Math.random().toString(36).slice(2, 7);
  const base = `swp-${tenantCode}`.toLowerCase().replace(/[^a-z0-9-]/g, '-');
  return `${base}-${suffix}`.slice(0, 30);
}

async function createProject(tenantCode: string): Promise<{ projectId: string; projectNumber: string }> {
  const projectId = generateProjectId(tenantCode);
  const body: Record<string, unknown> = {
    projectId,
    displayName: tenantCode,
    labels: { tenant: tenantCode, managed_by: 'swahilipro-onboarding' },
  };
  if (PARENT_RESOURCE) body.parent = PARENT_RESOURCE;

  const op = await gfetch<any>(`${CLOUD_RESOURCE_MANAGER}/projects`, {
    method: 'POST',
    body: JSON.stringify(body),
  });
  const result = await pollOperation<any>(`${CLOUD_RESOURCE_MANAGER}/${op.name}`);
  const projectNumber: string = result.name?.split('/')[1] ?? result.projectNumber;
  return { projectId, projectNumber };
}

async function linkBilling(projectId: string): Promise<void> {
  if (!BILLING_ACCOUNT) {
    throw new Error('CONTROL_PLANE_BILLING_ACCOUNT is not set — required to enable Blaze-tier services.');
  }
  await gfetch(`${CLOUD_BILLING}/projects/${projectId}/billingInfo`, {
    method: 'PUT',
    body: JSON.stringify({ billingAccountName: BILLING_ACCOUNT }),
  });
}

async function enableApis(projectId: string): Promise<void> {
  const op = await gfetch<any>(`${SERVICE_USAGE}/projects/${projectId}/services:batchEnable`, {
    method: 'POST',
    body: JSON.stringify({ serviceIds: REQUIRED_APIS }),
  });
  if (op.name) {
    await pollOperation(`${SERVICE_USAGE}/${op.name}`);
  }
}

async function addFirebase(projectId: string): Promise<void> {
  const op = await gfetch<any>(`${FIREBASE_MGMT}/projects/${projectId}:addFirebase`, {
    method: 'POST',
    body: JSON.stringify({}),
  });
  await pollOperation(`${FIREBASE_MGMT}/${op.name}`);
}

async function createFirestoreDatabase(projectId: string, region: string): Promise<void> {
  try {
    const op = await gfetch<any>(`${FIRESTORE}/projects/${projectId}/databases?databaseId=(default)`, {
      method: 'POST',
      body: JSON.stringify({ locationId: region, type: 'FIRESTORE_NATIVE' }),
    });
    await pollOperation(`${FIRESTORE}/${op.name}`);
  } catch (err: any) {
    // addFirebase sometimes provisions the default database automatically —
    // treat "already exists" as success rather than failing the whole pipeline.
    if (!String(err.message).includes('ALREADY_EXISTS')) throw err;
  }
}

async function deployFirestoreRules(projectId: string, rulesSource: string): Promise<void> {
  const ruleset = await gfetch<any>(`${FIREBASE_RULES}/projects/${projectId}/rulesets`, {
    method: 'POST',
    body: JSON.stringify({ source: { files: [{ name: 'firestore.rules', content: rulesSource }] } }),
  });
  await gfetch(`${FIREBASE_RULES}/projects/${projectId}/releases`, {
    method: 'POST',
    body: JSON.stringify({
      name: `projects/${projectId}/releases/cloud.firestore`,
      rulesetName: ruleset.name,
    }),
  });
}

async function createAndroidApp(projectId: string, packageName: string): Promise<{ appId: string }> {
  const op = await gfetch<any>(`${FIREBASE_MGMT}/projects/${projectId}/androidApps`, {
    method: 'POST',
    body: JSON.stringify({ packageName, displayName: packageName }),
  });
  const result = await pollOperation<any>(`${FIREBASE_MGMT}/${op.name}`);
  return { appId: result.appId };
}

async function fetchAndroidConfig(
  projectId: string,
  appId: string,
  projectNumber: string
): Promise<TenantConfig> {
  const res = await gfetch<any>(`${FIREBASE_MGMT}/projects/${projectId}/androidApps/${appId}/config`);
  const json = JSON.parse(Buffer.from(res.configFileContents, 'base64').toString('utf8'));
  const client = json.client[0];
  return {
    projectId,
    projectNumber,
    appId,
    apiKey: client.api_key[0].current_key,
    messagingSenderId: projectNumber,
    storageBucket: json.project_info?.storage_bucket ?? '',
    authDomain: `${projectId}.firebaseapp.com`,
  };
}

async function createTenantAdminUser(projectId: string, ownerEmail: string): Promise<void> {
  // The control-plane service account is the creator (and therefore Owner) of every
  // project this pipeline creates, so the Admin SDK can act directly against the new
  // project via a scoped, named app — no per-tenant service account key needed.
  const tenantApp = admin.initializeApp({ projectId }, projectId);
  try {
    const auth = tenantApp.auth();
    const user = await auth.createUser({ email: ownerEmail, emailVerified: false });
    await auth.setCustomUserClaims(user.uid, { role: 'tenantAdmin' });
    // Send this link through your own email flow rather than relying on Firebase's default templates.
    await auth.generatePasswordResetLink(ownerEmail);
  } finally {
    await tenantApp.delete();
  }
}

export async function provisionTenantProject(input: TenantOnboardingInput): Promise<TenantConfig> {
  const { tenantCode, androidPackageName, ownerEmail } = input;
  const firestoreRegion = input.firestoreRegion || DEFAULT_FIRESTORE_REGION;

  const { projectId, projectNumber } = await createProject(tenantCode);
  await linkBilling(projectId);
  await enableApis(projectId);
  await addFirebase(projectId);
  await createFirestoreDatabase(projectId, firestoreRegion);
  await deployFirestoreRules(projectId, DEFAULT_RULES);
  const { appId } = await createAndroidApp(projectId, androidPackageName);
  const config = await fetchAndroidConfig(projectId, appId, projectNumber);
  await createTenantAdminUser(projectId, ownerEmail);

  return config;
}
