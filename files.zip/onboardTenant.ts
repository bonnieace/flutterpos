import { onCall, HttpsError } from 'firebase-functions/v2/https';
import * as admin from 'firebase-admin';

const db = () => admin.firestore();

/**
 * Called from your internal admin tool (not the distributed POS app) to kick off
 * onboarding for a new tenant. This just enqueues the job — the real work happens
 * in onTenantProvisionRequested, triggered by the Firestore write below.
 */
export const onboardTenant = onCall(async (request) => {
  if (request.auth?.token.role !== 'superAdmin') {
    throw new HttpsError('permission-denied', 'Only SwahiliPro admins can onboard tenants.');
  }

  const { tenantCode, businessName, ownerEmail, androidPackageName } = request.data ?? {};
  if (!tenantCode || !businessName || !ownerEmail || !androidPackageName) {
    throw new HttpsError(
      'invalid-argument',
      'tenantCode, businessName, ownerEmail, and androidPackageName are all required.'
    );
  }

  const ref = db().collection('tenants').doc(tenantCode);
  const existing = await ref.get();
  if (existing.exists) {
    throw new HttpsError('already-exists', `Tenant '${tenantCode}' already exists.`);
  }

  await ref.set({
    tenantCode,
    businessName,
    ownerEmail,
    androidPackageName,
    status: 'pending',
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { tenantCode, status: 'pending' };
});
