import { onCall, HttpsError } from 'firebase-functions/v2/https';
import * as admin from 'firebase-admin';

const db = () => admin.firestore();

/**
 * Called by the distributed POS app on first run (after the user enters/scans
 * their tenant code) to resolve which Firebase project it should talk to.
 *
 * enforceAppCheck is important here: this endpoint is effectively public (any
 * caller who knows or guesses a tenant code can hit it), so App Check gates it
 * to requests coming from your real app binary rather than an arbitrary script.
 */
export const getTenantConfig = onCall({ enforceAppCheck: true }, async (request) => {
  const { tenantCode } = request.data ?? {};
  if (!tenantCode) {
    throw new HttpsError('invalid-argument', 'tenantCode is required.');
  }

  const snap = await db().collection('tenants').doc(tenantCode).get();
  if (!snap.exists) {
    throw new HttpsError('not-found', `Unknown tenant code '${tenantCode}'.`);
  }

  const data = snap.data()!;
  if (data.status === 'error') {
    throw new HttpsError('internal', 'Tenant provisioning failed. Contact support.');
  }
  if (data.status !== 'ready') {
    throw new HttpsError('unavailable', 'This tenant is still being set up. Try again shortly.');
  }

  return { config: data.config };
});
