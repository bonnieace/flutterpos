export interface TenantOnboardingInput {
  tenantCode: string;          // unique slug, becomes part of the generated projectId
  businessName: string;
  ownerEmail: string;          // becomes the first tenant-admin user in the new project
  androidPackageName: string; // MUST match the applicationId of the single distributed APK
  firestoreRegion?: string;    // e.g. 'europe-west1' — default set in projectProvisioner.ts
}

export interface TenantConfig {
  projectId: string;
  projectNumber: string;
  appId: string;
  apiKey: string;
  messagingSenderId: string;
  storageBucket: string;
  authDomain: string;
}

export type TenantStatus = 'pending' | 'provisioning' | 'ready' | 'error';

export interface TenantDoc {
  tenantCode: string;
  businessName: string;
  ownerEmail: string;
  androidPackageName: string;
  status: TenantStatus;
  error?: string;
  config?: TenantConfig;
  createdAt: FirebaseFirestore.FieldValue | FirebaseFirestore.Timestamp;
  updatedAt: FirebaseFirestore.FieldValue | FirebaseFirestore.Timestamp;
}
