import { GoogleAuth } from 'google-auth-library';

const SCOPES = ['https://www.googleapis.com/auth/cloud-platform'];

let cachedAuth: GoogleAuth | null = null;

function getAuth(): GoogleAuth {
  if (!cachedAuth) {
    // Uses Application Default Credentials — i.e. the Cloud Functions runtime
    // service account. See README for the IAM roles that account needs.
    cachedAuth = new GoogleAuth({ scopes: SCOPES });
  }
  return cachedAuth;
}

async function getAccessToken(): Promise<string> {
  const client = await getAuth().getClient();
  const token = await client.getAccessToken();
  if (!token.token) {
    throw new Error('Failed to obtain an access token for the control-plane service account.');
  }
  return token.token;
}

/**
 * Authenticated JSON fetch against any Google API, using the control-plane
 * service account's credentials.
 */
export async function gfetch<T = any>(url: string, init: RequestInit = {}): Promise<T> {
  const token = await getAccessToken();
  const res = await fetch(url, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(init.headers || {}),
    },
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`${init.method || 'GET'} ${url} -> ${res.status}: ${JSON.stringify(body)}`);
  }
  return body as T;
}

/**
 * Polls a Google API long-running Operation until it completes.
 * `operationUrl` must be the fully-qualified GET url for the operation, e.g.
 * `https://firebase.googleapis.com/v1beta1/${op.name}`.
 */
export async function pollOperation<T = any>(
  operationUrl: string,
  { intervalMs = 3000, timeoutMs = 5 * 60 * 1000 } = {}
): Promise<T> {
  const start = Date.now();
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const op = await gfetch<any>(operationUrl);
    if (op.done) {
      if (op.error) {
        throw new Error(`Operation failed: ${JSON.stringify(op.error)}`);
      }
      return op.response as T;
    }
    if (Date.now() - start > timeoutMs) {
      throw new Error(`Operation timed out after ${timeoutMs}ms: ${operationUrl}`);
    }
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
}
