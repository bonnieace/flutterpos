# Tenant onboarding — project-per-tenant automation

Drop the `src/` files into your existing Cloud Functions project (alongside
your current AquaFlow/ChillTent functions). Nothing here needs its own
project — it runs as functions in your **control-plane** (main) Firebase
project and calls out to Google's APIs to provision a brand-new Firebase
project per tenant.

## What it does

1. `onboardTenant` (onCall, admin-gated) — writes `tenants/{tenantCode}`
   with `status: 'pending'`.
2. `onTenantProvisionRequested` (Firestore trigger) — does the actual work:
   creates a GCP project → links billing → enables APIs → attaches Firebase
   → creates the default Firestore database → deploys security rules →
   registers an Android app → fetches its config → seeds the tenant-admin
   user → writes `status: 'ready'` with the resulting config back onto the
   same doc.
3. `getTenantConfig` (onCall, App Check-gated) — called by the distributed
   APK on first run with a tenant code; returns that tenant's Firebase
   config once provisioning is `ready`.

The app itself ships with only your control-plane project's config baked
in. Once it has the tenant's config from `getTenantConfig`, initialize a
second, named Firebase app instance with it (`Firebase.initializeApp(name:
tenantCode, options: ...)`) — same BYOF pattern you're already using in
AquaFlow.

## Install

```bash
npm install google-auth-library
```

(`firebase-admin` and `firebase-functions` v2 are assumed to already be
dependencies.)

## Required setup before deploying

**1. Decide whether you have a GCP Organization.** If your Google Cloud
account has no Cloud Identity/Workspace org, project creation without a
`parent` still works, but it's subject to a default per-account project
creation quota (historically small — low double digits). That quota is
raisable via a support request, but if you expect to onboard many tenants,
it's worth setting up a Cloud Identity org now so you can (a) organize
tenant projects under a Folder, (b) request a much larger quota against the
org rather than a personal account, and (c) grant IAM roles at the folder
level so every new project inherits them automatically.

**2. Service account for the Functions runtime.** The identity your
functions run as needs, at minimum:
- `roles/resourcemanager.projectCreator` — granted at the org/folder level
  if you have one, otherwise at the account level
- `roles/billing.user` — on the billing account you'll link new projects to
- `roles/serviceusage.serviceUsageAdmin`
- `roles/firebase.admin`

Because this account creates each project, it becomes that project's Owner
automatically — that's what lets `createTenantAdminUser` use the Admin SDK
cross-project without a separate per-tenant service account key.

**3. Environment variables** (set via `firebase functions:config:set` or
`.env` for 2nd-gen):

```
CONTROL_PLANE_BILLING_ACCOUNT=billingAccounts/XXXXXX-XXXXXX-XXXXXX
CONTROL_PLANE_PARENT_RESOURCE=folders/123456789012   # omit if no GCP org
CONTROL_PLANE_FIRESTORE_REGION=europe-west1          # no Africa Firestore region yet;
                                                       # europe-west1/west4 are typically
                                                       # lowest-latency to Nairobi
```

**4. App Check.** `getTenantConfig` is reachable by anything that knows a
tenant code, since it runs before the app has any per-tenant auth. Set up
Play Integrity-backed App Check on the control-plane project and enforce it
on this function, or an attacker can enumerate tenant codes and read
(non-sensitive, but still) config data.

## Known gaps — this is a solid starting point, not hardened for production

- **No offboarding/rollback.** If a step fails partway through, you'll have
  a partially-provisioned GCP project sitting around costing nothing but
  cluttering your console. Worth adding a cleanup path (`projects.delete`,
  which schedules deletion after a 30-day grace period) triggered from the
  `status: 'error'` branch.
- **No retry logic** on individual steps — a transient API error fails the
  whole pipeline and the tenant doc goes straight to `error`.
- **Single Android app per tenant project.** If you also need Web or iOS
  builds against the same tenant projects, add equivalent `createIosApp` /
  create-web-app calls following the same pattern as `createAndroidApp`.
- **Quotas will bite you before code does.** The actual ceiling on how many
  tenants you can onboard this way is Google's project-count quota, not
  anything in this pipeline — plan the org/folder setup above before you
  need it, not after tenant #20 fails to provision.
