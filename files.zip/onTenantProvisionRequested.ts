import { onDocumentCreated } from 'firebase-functions/v2/firestore';
import * as admin from 'firebase-admin';
import { provisionTenantProject } from './lib/projectProvisioner';
import { TenantDoc } from './lib/types';

/**
 * Runs the full provisioning pipeline in the background whenever a new
 * `tenants/{tenantCode}` doc is created with status 'pending'. Kept as a
 * separate background trigger (rather than doing this inline in onboardTenant)
 * because project creation + Firestore setup can take a couple of minutes —
 * too long to hold open a synchronous client call.
 */
export const onTenantProvisionRequested = onDocumentCreated(
  {
    document: 'tenants/{tenantCode}',
    timeoutSeconds: 540, // raise further if provisioning routinely runs long; check your
    memory: '512MiB', //   Cloud Functions 2nd-gen timeout ceiling before going higher
    region: 'europe-west1',
  },
  async (event) => {
    const snap = event.data;
    if (!snap) return;

    const data = snap.data() as TenantDoc;
    if (data.status !== 'pending') return;

    const ref = snap.ref;
    await ref.update({ status: 'provisioning', updatedAt: admin.firestore.FieldValue.serverTimestamp() });

    try {
      const config = await provisionTenantProject({
        tenantCode: event.params.tenantCode,
        businessName: data.businessName,
        ownerEmail: data.ownerEmail,
        androidPackageName: data.androidPackageName,
      });

      await ref.update({
        status: 'ready',
        config,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    } catch (err: any) {
      await ref.update({
        status: 'error',
        error: err?.message ?? String(err),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      // Re-throw so the error surfaces in Cloud Functions logs / error reporting too.
      throw err;
    }
  }
);
